import { create } from 'zustand';

type UserRole = 'admin' | 'doctor' | 'nurse' | 'patient';

interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  login: (user) => set({ user, isAuthenticated: true }),
  logout: () => set({ user: null, isAuthenticated: false }),
}));