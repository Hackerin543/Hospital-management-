import React from 'react';

export function Dashboard() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <div className="p-6 bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold">Total Patients</h3>
        <p className="text-3xl font-bold text-blue-600">1,234</p>
      </div>
      <div className="p-6 bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold">Today's Appointments</h3>
        <p className="text-3xl font-bold text-green-600">42</p>
      </div>
      <div className="p-6 bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold">Available Doctors</h3>
        <p className="text-3xl font-bold text-purple-600">18</p>
      </div>
      <div className="p-6 bg-white rounded-lg shadow">
        <h3 className="text-lg font-semibold">Pending Reports</h3>
        <p className="text-3xl font-bold text-orange-600">7</p>
      </div>
    </div>
  );
}